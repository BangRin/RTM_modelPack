
var renderClass = "jp.ngt.rtm.render.VehiclePartsRenderer";
importPackage(Packages.org.lwjgl.opengl);
importPackage(Packages.jp.ngt.rtm.render);
importPackage(Packages.jp.ngt.ngtlib.math);
importPackage(Packages.jp.ngt.rtm)
importPackage(Packages.jp.ngt.rtm.entity.train.util);

//##### �I�u�W�F�N�g��` ####################
function init(par1, par2)
{
	//�ԑ�
	body = renderer.registerParts(new Parts("Fa1" ,"Fa3" ,"exterior" ,"Interior" ,"door" ,"hood" ,"front" ,"cab" ,"light" ,"in_car_equipment" ,"in_car_equipment_mx" ,"skirt" ,"roof_eq" ,"through_door" ,"alpha" ,"coupler" ,"lambord" ,"Side_MS" ,"frontA" ,"frontB" ,"frontC" ,"cabpanel" ,"Lever" ,"M" ,"N" ,"UF1" ,"UF2" ,"panta" ,"roofeq"));
	lightF = renderer.registerParts(new Parts("lightF"));
	lightB = renderer.registerParts(new Parts("lightB", "lightR"));
	ExLF = renderer.registerParts(new Parts("ExLightF"));
	ExLB = renderer.registerParts(new Parts("ExLightB"));
	door_LF = renderer.registerParts(new Parts("doorFL"));
	door_RF = renderer.registerParts(new Parts("doorFR"));
	door_LB = renderer.registerParts(new Parts("doorBL"));
	door_RB = renderer.registerParts(new Parts("doorBR"));
	alpha = renderer.registerParts(new Parts("alpha"));
	door_LFa = renderer.registerParts(new Parts("doorFL1"));
	door_RFa = renderer.registerParts(new Parts("doorFR1"));
	door_LBa = renderer.registerParts(new Parts("doorBL1"));
	door_RBa = renderer.registerParts(new Parts("doorBR1"));
	

	//�p���^
	pantabase = renderer.registerParts(new Parts("panta_AB1", "panta_AB2", "panta_A1", "panta_A2", "panta_B1", "panta_B2", "panta_C1", "panta_C2", "panta_D1", "panta_D2"));
	pantaA11 = renderer.registerParts(new Parts("panta_A1_1"));
	pantaA12 = renderer.registerParts(new Parts("panta_A1_2"));
	pantaA13 = renderer.registerParts(new Parts("panta_A1_3"));
	pantaA14 = renderer.registerParts(new Parts("panta_A1_4"));
	pantaA15 = renderer.registerParts(new Parts("panta_A1_5"));
	pantaA21 = renderer.registerParts(new Parts("panta_A2_1"));
	pantaA22 = renderer.registerParts(new Parts("panta_A2_2"));
	pantaA23 = renderer.registerParts(new Parts("panta_A2_3"));
	pantaA24 = renderer.registerParts(new Parts("panta_A2_4"));
	pantaA25 = renderer.registerParts(new Parts("panta_A2_5"));
	pantaB11 = renderer.registerParts(new Parts("panta_B1_1"));
	pantaB12 = renderer.registerParts(new Parts("panta_B1_2"));
	pantaB13 = renderer.registerParts(new Parts("panta_B1_3"));
	pantaB14 = renderer.registerParts(new Parts("panta_B1_4"));
	pantaB15 = renderer.registerParts(new Parts("panta_B1_5"));
	pantaB21 = renderer.registerParts(new Parts("panta_B2_1"));
	pantaB22 = renderer.registerParts(new Parts("panta_B2_2"));
	pantaB23 = renderer.registerParts(new Parts("panta_B2_3"));
	pantaB24 = renderer.registerParts(new Parts("panta_B2_4"));
	pantaB25 = renderer.registerParts(new Parts("panta_B2_5"));
	pantaC11 = renderer.registerParts(new Parts("panta_C1_1"));
	pantaC12 = renderer.registerParts(new Parts("panta_C1_2"));
	pantaC13 = renderer.registerParts(new Parts("panta_C1_3"));
	pantaC14 = renderer.registerParts(new Parts("panta_C1_4"));
	pantaC15 = renderer.registerParts(new Parts("panta_C1_5"));
	pantaC21 = renderer.registerParts(new Parts("panta_C2_1"));
	pantaC22 = renderer.registerParts(new Parts("panta_C2_2"));
	pantaC23 = renderer.registerParts(new Parts("panta_C2_3"));
	pantaC24 = renderer.registerParts(new Parts("panta_C2_4"));
	pantaC25 = renderer.registerParts(new Parts("panta_C2_5"));
	pantaD11 = renderer.registerParts(new Parts("panta_D1_1"));
	pantaD12 = renderer.registerParts(new Parts("panta_D1_2"));
	pantaD13 = renderer.registerParts(new Parts("panta_D1_3"));
	pantaD14 = renderer.registerParts(new Parts("panta_D1_4"));
	pantaD15 = renderer.registerParts(new Parts("panta_D1_5"));
	pantaD21 = renderer.registerParts(new Parts("panta_D2_1"));
	pantaD22 = renderer.registerParts(new Parts("panta_D2_2"));
	pantaD23 = renderer.registerParts(new Parts("panta_D2_3"));
	pantaD24 = renderer.registerParts(new Parts("panta_D2_4"));
	pantaD25 = renderer.registerParts(new Parts("panta_D2_5"));
}


function MCVersionChecker() {
    var varsion = RTMCore.VERSION;
    if (varsion.indexOf("1.7.10") >= 0) return "1.7.10";
    else if (varsion.indexOf("2.0") >= 0) return "1.8.9";
    else if (varsion.indexOf("2.1") >= 0) return "1.9.4";
    else if (varsion.indexOf("2.2") >= 0) return "1.10.2";
    else if (varsion.indexOf("2.4") >= 0) return "1.12.2";
    else return "unknown";
}



//##### render ####################
function render(entity, pass, par3)
{
	//���l�ݒ�
	var doorMove = 0.64, //�h�A�J����(m)
		pantaDistance = 7.0, //�p���^���S�̑O��ʒu(m)
		pantaType = "Compatible"; //�p���^��(Normal:�W��-�i�[ / W51:W51-�i�[ / Compatible:�W��-W51)
	
	GL11.glPushMatrix();
	
	//�ʏ�`��
	if(pass == 0){
		body.render(renderer);
		render_door(entity, doorMove);
		render_light(entity);
		render_panta(entity, pantaDistance, pantaType);
	}
	
	//�������`��
	if(pass == 1){
		alpha.render(renderer);
		render_door_a(entity, doorMove);
	}
	
	//�������`��
	if(pass > 1){
		body.render(renderer);
		render_light(entity);
		render_door(entity, doorMove);
	}
	
	GL11.glPopMatrix();
}


//##### render_���C�g ####################
function render_light(entity){
	
	var varsion = MCVersionChecker();
	var lightMove = 0;
	var ExState = 0;
	

	if(entity != null){

	if(varsion == "1.7.10" || varsion == "1.8.9" || varsion == "1.9.4"){
	    ExState = entity.getTrainStateData(11);
	}else{
	    ExState = entity.getVehicleState(TrainState.getStateType(11));
	}

	}




	try{
		lightMove = (entity.seatRotation)/ 45;
	}catch(e){}
	

	 if(lightMove < 0){
 	   if(ExState >= 1){
	    GL11.glPushMatrix();
	     ExLF.render(renderer);
	    GL11.glPopMatrix();
	   }else{
	    GL11.glPushMatrix();
	     ExLB.render(renderer);
	    GL11.glPopMatrix();
  	   }
	 }else{
	  GL11.glPushMatrix();
	  ExLB.render(renderer);
	  GL11.glPopMatrix();
	 }

	 if(lightMove < 0){
	  GL11.glPushMatrix();
	  lightF.render(renderer);
	  GL11.glPopMatrix();
	 }else{
	  GL11.glPushMatrix();
	  lightB.render(renderer);
	  GL11.glPopMatrix();
	 }
}





//##### render_�h�A ####################
function render_door(entity,doorMove){
	
	var doorMoveL = 0.0,
		doorMoveR = 0.0;
	
	try{
		doorMoveL = renderer.sigmoid(entity.doorMoveL / 60) * doorMove;
		doorMoveR = renderer.sigmoid(entity.doorMoveR / 60) * doorMove;
	}catch(e){}
	
	GL11.glPushMatrix();
	GL11.glTranslatef(0.0, 0.0, doorMoveL);
	door_LF.render(renderer);
	GL11.glPopMatrix();
	
	GL11.glPushMatrix();
	GL11.glTranslatef(0.0, 0.0, -doorMoveL);
	door_LB.render(renderer);
	GL11.glPopMatrix();
	
	GL11.glPushMatrix();
	GL11.glTranslatef(0.0, 0.0, doorMoveR);
	door_RF.render(renderer);
	GL11.glPopMatrix();
	
	GL11.glPushMatrix();
	GL11.glTranslatef(0.0, 0.0, -doorMoveR);
	door_RB.render(renderer);
	GL11.glPopMatrix();
}

//##### render_�����h�A ####################
function render_door_a(entity,doorMove){
	
	var doorMoveL = 0.0,
		doorMoveR = 0.0;
	
	try{
		doorMoveL = renderer.sigmoid(entity.doorMoveL / 60) * doorMove;
		doorMoveR = renderer.sigmoid(entity.doorMoveR / 60) * doorMove;
	}catch(e){}
	
	GL11.glPushMatrix();
	GL11.glTranslatef(0.0, 0.0, doorMoveL);
	door_LFa.render(renderer);
	GL11.glPopMatrix();
	
	GL11.glPushMatrix();
	GL11.glTranslatef(0.0, 0.0, -doorMoveL);
	door_LBa.render(renderer);
	GL11.glPopMatrix();
	
	GL11.glPushMatrix();
	GL11.glTranslatef(0.0, 0.0, doorMoveR);
	door_RFa.render(renderer);
	GL11.glPopMatrix();
	
	GL11.glPushMatrix();
	GL11.glTranslatef(0.0, 0.0, -doorMoveR);
	door_RBa.render(renderer);
	GL11.glPopMatrix();
}



//##### render_�p���^ ####################
function render_panta(entity,pantaDistance,pantaType){
	
	var pantaState = 0.0,
		pDis = pantaDistance;
	
	try{
		pantaState = renderer.sigmoid(entity.pantograph_F / 40);
	}catch(e){}
	
	switch(pantaType){
		case "W51" :
			var pAro1 = pantaState * 18 + 15,
				pAro2 = pantaState * 37 + 26,
				pBro1 = pantaState * 15 + 12,
				pBro2 = pantaState * 39 + 27,
				pCro1 = pantaState * 15 + 14,
				pCro2 = pantaState * 35 + 24,
				pCro4 = pantaState * 36 + 24,
				pCro5 = pantaState * 38 + 28;
			break;
		case "Compatible" :
			var pAro1 = pantaState * 15,
				pAro2 = pantaState * 26,
				pBro1 = pantaState * 12,
				pBro2 = pantaState * 27,
				pCro1 = pantaState * 14,
				pCro2 = pantaState * 24,
				pCro4 = pantaState * 24,
				pCro5 = pantaState * 28;
			break;
		default :
			var pAro1 = pantaState * 33,
				pAro2 = pantaState * 63,
				pBro1 = pantaState * 27,
				pBro2 = pantaState * 66,
				pCro1 = pantaState * 29,
				pCro2 = pantaState * 59,
				pCro4 = pantaState * 60,
				pCro5 = pantaState * 66;
			break;
	}
	
	pantabase.render(renderer);
	
	//�p���^A1
	GL11.glPushMatrix();
	renderer.rotate(pAro1, 'X', 0.0, 2.8784, pDis+0.5224);
	pantaA11.render(renderer);
		renderer.rotate(-pAro2, 'X', 0.0, 3.6729, pDis+1.5431);
		pantaA12.render(renderer);
			renderer.rotate(pAro2-pAro1, 'X', 0.0, 4.6101, pDis+0.0935);
			pantaA13.render(renderer);
	GL11.glPopMatrix();
	GL11.glPushMatrix();
	renderer.rotate(-pAro1, 'X', 0.0, 2.8784, pDis-0.5224);
	pantaA14.render(renderer);
		renderer.rotate(pAro2, 'X', 0.0, 3.6729, pDis-1.5431);
		pantaA15.render(renderer);
	GL11.glPopMatrix();
	
	//�p���^A2
	GL11.glPushMatrix();
	renderer.rotate(pAro1, 'X', 0.0, 2.8784, -pDis+0.5224);
	pantaA21.render(renderer);
		renderer.rotate(-pAro2, 'X', 0.0, 3.6729, -pDis+1.5431);
		pantaA22.render(renderer);
			renderer.rotate(pAro2-pAro1, 'X', 0.0, 4.6101, -pDis+0.0935);
			pantaA23.render(renderer);
	GL11.glPopMatrix();
	GL11.glPushMatrix();
	renderer.rotate(-pAro1, 'X', 0.0, 2.8784, -pDis-0.5224);
	pantaA24.render(renderer);
		renderer.rotate(pAro2, 'X', 0.0, 3.6729, -pDis-1.5431);
		pantaA25.render(renderer);
	GL11.glPopMatrix();
	
	//�p���^B1
	GL11.glPushMatrix();
	renderer.rotate(pBro1, 'X', 0.0, 2.8784, pDis-0.5224);
	pantaB11.render(renderer);
		renderer.rotate(-pBro2, 'X', 0.0, 3.8526, pDis+0.93);
		pantaB12.render(renderer);
			renderer.rotate(pBro2-pBro1, 'X', 0.0, 4.6227, pDis+0.0229);
			pantaB13.render(renderer);
	GL11.glPopMatrix();
	GL11.glPushMatrix();
	renderer.rotate(-pBro1, 'X', 0.0, 2.8784, pDis+0.5224);
	pantaB14.render(renderer);
		renderer.rotate(pBro2, 'X', 0.0, 3.8526, pDis-0.93);
		pantaB15.render(renderer);
	GL11.glPopMatrix();
	
	//�p���^B2
	GL11.glPushMatrix();
	renderer.rotate(pBro1, 'X', 0.0, 2.8784, -pDis-0.5224);
	pantaB21.render(renderer);
		renderer.rotate(-pBro2, 'X', 0.0, 3.8526, -pDis+0.93);
		pantaB22.render(renderer);
			renderer.rotate(pBro2-pBro1, 'X', 0.0, 4.6227, -pDis+0.0229);
			pantaB23.render(renderer);
	GL11.glPopMatrix();
	GL11.glPushMatrix();
	renderer.rotate(-pBro1, 'X', 0.0, 2.8784, -pDis+0.5224);
	pantaB24.render(renderer);
		renderer.rotate(pBro2, 'X', 0.0, 3.8526, -pDis-0.93);
		pantaB25.render(renderer);
	GL11.glPopMatrix();
	
	//�p���^C1
	GL11.glPushMatrix();
	renderer.rotate(pCro1, 'X', 0.0, 3.0118, pDis-0.314);
	pantaC11.render(renderer);
			GL11.glPushMatrix();
			renderer.rotate(-pCro4, 'X', 0.0, 3.6084, pDis+0.7523);
			pantaC14.render(renderer);
			GL11.glPopMatrix();
		renderer.rotate(-pCro2, 'X', 0.0, 3.7151, pDis+0.8641);
		pantaC12.render(renderer);
			GL11.glPushMatrix();
			renderer.rotate(pCro2-pCro1, 'X', 0.0, 4.5998, pDis-0.6186);
			pantaC13.render(renderer);
			GL11.glPopMatrix();
			renderer.rotate(pCro5, 'X', 0.0, 3.5258, pDis+0.9758);
			pantaC15.render(renderer);
	GL11.glPopMatrix();
	
	//�p���^C2
	GL11.glPushMatrix();
	renderer.rotate(pCro1, 'X', 0.0, 3.0118, -pDis-0.314);
	pantaC21.render(renderer);
			GL11.glPushMatrix();
			renderer.rotate(-pCro4, 'X', 0.0, 3.6084, -pDis+0.7523);
			pantaC24.render(renderer);
			GL11.glPopMatrix();
		renderer.rotate(-pCro2, 'X', 0.0, 3.7151, -pDis+0.8641);
		pantaC22.render(renderer);
			GL11.glPushMatrix();
			renderer.rotate(pCro2-pCro1, 'X', 0.0, 4.5998, -pDis-0.6186);
			pantaC23.render(renderer);
			GL11.glPopMatrix();
			renderer.rotate(pCro5, 'X', 0.0, 3.5258, -pDis+0.9758);
			pantaC25.render(renderer);
	GL11.glPopMatrix();
	
	//�p���^D1
	GL11.glPushMatrix();
	renderer.rotate(-pCro1, 'X', 0.0, 3.0118, pDis+0.3140);
	pantaD11.render(renderer);
			GL11.glPushMatrix();
			renderer.rotate(pCro4, 'X', 0.0, 3.6084, pDis-0.7523);
			pantaD14.render(renderer);
			GL11.glPopMatrix();
		renderer.rotate(pCro2, 'X', 0.0, 3.7151, pDis-0.8641);
		pantaD12.render(renderer);
			GL11.glPushMatrix();
			renderer.rotate(-pCro2+pCro1, 'X', 0.0, 4.5998, pDis+0.6186);
			pantaD13.render(renderer);
			GL11.glPopMatrix();
			renderer.rotate(-pCro5, 'X', 0.0, 3.5258, pDis-0.9758);
			pantaD15.render(renderer);
	GL11.glPopMatrix();
	
	//�p���^D2
	GL11.glPushMatrix();
	renderer.rotate(-pCro1, 'X', 0.0, 3.0118, -pDis+0.314);
	pantaD21.render(renderer);
			GL11.glPushMatrix();
			renderer.rotate(pCro4, 'X', 0.0, 3.6084, -pDis-0.7523);
			pantaD24.render(renderer);
			GL11.glPopMatrix();
		renderer.rotate(pCro2, 'X', 0.0, 3.7151, -pDis-0.8641);
		pantaD22.render(renderer);
			GL11.glPushMatrix();
			renderer.rotate(-pCro2+pCro1, 'X', 0.0, 4.5998, -pDis+0.6186);
			pantaD23.render(renderer);
			GL11.glPopMatrix();
			renderer.rotate(-pCro5, 'X', 0.0, 3.5258, -pDis-0.9758);
			pantaD25.render(renderer);
	GL11.glPopMatrix();
}
